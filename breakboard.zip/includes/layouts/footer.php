    <div id="footer">Copyright 2020, Paul Plamondon, Developer</div>

	</body>
</html>
<?php
  // 5. Close database connection
	if (isset($connection)) {
	  mysqli_close($connection);
	}
	
?>
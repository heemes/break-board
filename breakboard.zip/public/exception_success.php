<?php include_once("../includes/layouts/header.php"); ?>

<div id="main">
  <div id="navigation">
	&nbsp;
  </div>
  <div id="page">
    
    <h2>Thank you for submitting your exception</h2>

  </div>
</div>

<?php 
	include("../includes/layouts/footer.php");
	ob_end_flush();
?>

var list = document.getElementById("list-items");
var count-out = (list.match(/out/g) || []).length;
var count-in = (list.match(/in/g) || []).length;
if $count-out - $count-in > 2 then don't show form;
else show form;